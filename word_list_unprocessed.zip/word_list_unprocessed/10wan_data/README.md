# 103976
103976个英语单词库
（sql版，csv版，Excel版）
库表中包含英文单词，中文翻译，单词的词性及多种词义,
执行SQL语句就可以生成表，支持SQL Server，MySQL等多种数据库。

支持phpMyAdmin直接导入。

## 文件列表说明：
- EnWords.sql SQL导入文件，MySQL版本，可以直接在phpMyAdmin中导入。也可以直接导入MS SQL Server各个版本中。
- EnWords.csv Excel格式文件，也可以用于导入到数据库中。
- SQLQuery.sql MS SQL Server版本。执行效率不高，推荐用EnWords的版本。


# 总数展示：共103976个单词。

![avatar](https://github.com/1eez/103976/blob/master/PIC-%E6%80%BB%E6%95%B0%E7%BB%9F%E8%AE%A1.png)

# 单词库表展示：

![avatar](https://github.com/1eez/103976/blob/master/PIC-%E5%8D%95%E8%AF%8D%E5%BA%93%E8%A1%A8%E5%B1%95%E7%A4%BA.png)

# SQL文件预览。

![avatar](https://github.com/1eez/103976/blob/master/PIC-sql%E6%96%87%E4%BB%B6%E9%A2%84%E8%A7%88.png)

# CSV文件预览：

![avatar](https://github.com/1eez/103976/blob/master/PIC-csv%E6%96%87%E4%BB%B6%E9%A2%84%E8%A7%88.png)

# Excel文件预览（Excel只能打开最前面的65535行数据）

![avatar](https://github.com/1eez/103976/blob/master/PIC-Excel%E6%96%87%E4%BB%B6%E9%A2%84%E8%A7%88.png)
