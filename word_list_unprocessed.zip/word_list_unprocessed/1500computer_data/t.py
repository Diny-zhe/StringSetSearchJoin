str_1='wo shi yi zhi da da niu  '
char_1='i'
nPos=str_1.index(char_1)
print(nPos)