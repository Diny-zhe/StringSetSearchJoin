# MorTransformation
A morphological transformation program for NLP course.
